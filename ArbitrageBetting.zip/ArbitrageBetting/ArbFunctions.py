# Function that takes two odds, and returns if the bet is profitable or not.
# If it is profitable, return the two bet amounts.

def IsProfitable_2(O1, O2):
    return [
        round(O1, 3),
        round(O1**2/O2, 3),
        round((1/(O1**-1 + O2**-1)-1)*100, 3)
    ]


def IsProfitable_3(O1, O2, O3):
    return [
        round(1/(1+(O1/O2)+(O1/O3)), 3),
        round(1/(1+(O2/O1)+(O2/O3)), 3),
        round(1/(1+(O3/O1)+(O3/O2)), 3),
        round((1/(O1**-1 + O2**-1 + O3**-1)-1)*100, 3)
    ]


def FindBestBets(bets):
    # Take in a list of bets, return the two bets with the best odds.

    Team1_Odds = [bet[6] for bet in bets]
    best_team_1 = (bets[Team1_Odds.index(max(Team1_Odds))][0], max(Team1_Odds))

    Team2_Odds = [bet[7] for bet in bets]
    best_team_2 = (bets[Team2_Odds.index(max(Team2_Odds))][0], max(Team2_Odds))

    draw_odds = [bet[8] for bet in bets]
    best_draw = (bets[draw_odds.index(max(draw_odds))][0], max(draw_odds))

    return [best_team_1, best_team_2, best_draw]


a = [(1, 'Gbets', 'w/l', '18-10-2021', 'Liverpool', 'Juventus', 3.0, 4.0, -1.0),
     (3, 'Sunbet', 'w/l', '18-10-2021', 'Liverpool', 'Juventus', 3.5, 3.0, -1.0),
     (6, 'HollyWoodBets', 'w/l', '18-10-2021', 'Liverpool', 'Juventus', 2.0, 2.5, -1.0)]


if __name__ == '__main__':
    print(FindBestBets(a))
