import sqlite3 as sq
import time

connection = sq.connect('Betting.db')

cursor = connection.cursor()


# Create bookie table

command1 = """CREATE TABLE IF NOT EXISTS
bookies(Bookie_ID TEXT PRIMARY KEY, Transaction_Fee FLOAT)"""

cursor.execute(command1)

# Creating a bets table
command2 = """CREATE TABLE IF NOT EXISTS
bets(
Bookie_ID TEXT,
BetType TEXT,   
DateOfMatch DATETIME,
Sport TEXT, 
Team1 TEXT, 
Team2 TEXT, 
O1 FLOAT,
O2 FLOAT,
O3 FLOAT, 
URLs TEXT,
FOREIGN KEY (Bookie_ID) REFERENCES bookies(Bookie_ID))"""

cursor.execute(command2)

command3 = """CREATE TABLE IF NOT EXISTS
arbs(
ROI FLOAT,
Bet1 INTEGER,
O1 FLOAT,
F1 FLOAT,
Bet2 INTEGER,
O2 FLOAT,
F2 FLOAT,
FOREIGN KEY (Bet1) REFERENCES bets(RowID),
FOREIGN KEY (Bet2) REFERENCES bets(RowID))
"""

cursor.execute(command3)


def DisplayBets():
    cursor.execute("select RowId, * FROM bets")
    print("{:<10} {:<15} {:<12} {:<15} {:<15} {:<20} {:<20} {:<7} {:<7} {:<7} {:<20} \n".format(
        'Row ID',
        'Bookie ID',
        'Bet Type',
        'Date',
        'Sport',
        'Team 1',
        'Team 2',
        'O1',
        'O2',
        'O3',
        'URL',
    ))

    for v in cursor.fetchall():

        RowID, Bookie_ID, Bet_Type, Date, Sport, Team1, Team2, O1, O2, O3, URLs = v
        print(("{:<10} {:<15} {:<12} {:<15} {:<15} {:<20} {:<20} {:<7} {:<7} {:<7} {:<20}").format(
            RowID,
            Bookie_ID,
            Bet_Type,
            Date,
            Sport,
            Team1,
            Team2,
            O1,
            O2,
            O3,
            URLs
        ))


def DisplayBookies():
    cursor.execute("SELECT * FROM Bookies")

    print("{:<20} {:<15} \n".format('Bookie', 'Fee'))

    for v in cursor.fetchall():
        BookieID, Fee = v
        print("{:<20} {:<15}".format(BookieID, Fee))


def DisplayArbs(statement):
    cursor.execute(statement)

    print("{:<10} {:<7} {:<7} {:<7} {:<7} {:<7} {:<7} \n".format(
        'ROI',
        'ID_1',
        'O1',
        'F1',
        'ID_2',
        'O2',
        'F2'
    ))

    for v in cursor.fetchall():
        print("{:<10} {:<7} {:<7} {:<7} {:<7} {:<7} {:<7}".format(
            v[0],
            v[1],
            v[2],
            v[3],
            v[4],
            v[5],
            v[6]
        ))


# Code to take data from text file an smack it into the database
# bookies
file = open("BookieData.txt", "r")
content = file.read()
file.close()

lines = content.split('\n')


for record in lines:

    data = record.split('!')

    a = f"""
    INSERT INTO BOOKIES VALUES
    (
    '{data[0]}',
    '{data[1]}'
    )
    """

    cursor.execute(a)

# bets
file = open("BetsData.txt", "r")
content = file.read()
file.close()

lines = content.split('\n')


for record in lines:

    data = record.split('!')

    a = f"""
    INSERT INTO BETS 
    (
    Bookie_ID,
    BetType,
    DateOfMatch,
    Sport,
    Team1,
    Team2,
    O1,
    O2,
    O3,
    URLs
    )
    VALUES
    (
    '{data[0]}',
    '{data[1]}',
    '{data[2]}',
    '{data[3]}',
    '{data[4]}',
    '{data[5]}',
    '{data[6]}',
    '{data[7]}',
    '{data[8]}',
    '{data[9]}'
    )
    """

    cursor.execute(a)


if __name__ == '__main__':
    DisplayBets()
