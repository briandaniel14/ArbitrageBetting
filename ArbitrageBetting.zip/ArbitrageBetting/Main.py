import ArbFunctions as Arb
import BettingDB as B
import datetime as D

# Cycle through database's dates
# Cycle through dates teams
# SQL the DB away to get only bets with that date and those teams
# Calculate arbitrages


def FindPossibleBets(line):

    CurrentDate = line[2]
    CurrentTeam1 = line[4]
    CurrentTeam2 = line[5]
    CurrentBetType = line[1]

    B.cursor.execute(f"""
    SELECT RowID, Bookie_ID, BetType, DateOfMatch, Team1, Team2, O1, O2, O3 
    FROM bets
    WHERE DateOfMatch = '{CurrentDate}' and BetType = '{CurrentBetType}'
    and (Team1 = '{CurrentTeam1}' and Team2 = '{CurrentTeam2}')     
    """
                     )

    return B.cursor.fetchall()


def FindArbs(db):

    output = []

    for line in db:

        best_bets = Arb.FindBestBets(FindPossibleBets(line))

        arb_value = Arb.IsProfitable_2(best_bets[0][1], best_bets[1][1])

        output.append((arb_value, best_bets))

    return output
    # find the best odds for each case


B.cursor.execute("SELECT * from bets")

Arbs = FindArbs(B.cursor.fetchall())


for Floats_Percentages, Odds_Ids in Arbs:

    # get the URL so u can plonk next to bet
    # maybe implement a ticker system
    # need to get unique values
    # need to plug these in an SQL db. primary key then use joins

    B.cursor.execute(f"""
        INSERT INTO arbs VALUES
        (
            '{Floats_Percentages[2]}',
            '{Odds_Ids[0][0]}',
            '{Odds_Ids[0][1]}',
            '{Floats_Percentages[0]}',
            '{Odds_Ids[1][0]}',
            '{Odds_Ids[1][1]}',
            '{Floats_Percentages[1]}'
        )
    """)

B.DisplayArbs("SELECT DISTINCT * FROM arbs WHERE ROI > 0 ORDER BY ROI DESC")
